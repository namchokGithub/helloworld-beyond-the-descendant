tag @s add starter_amethyst_received
give @s minecraft:budding_amethyst 3
give @s minecraft:bread 16